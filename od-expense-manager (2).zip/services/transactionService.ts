
import { Transaction, TransactionType, CATEGORIES } from '../types';

export const calculateTotals = (transactions: Transaction[]) => {
  return transactions.reduce(
    (acc, transaction) => {
      if (transaction.type === TransactionType.INCOME) {
        acc.income += transaction.amount;
      } else {
        acc.expense += transaction.amount;
      }
      acc.balance = acc.income - acc.expense;
      return acc;
    },
    { income: 0, expense: 0, balance: 0 }
  );
};

export const getCategoryById = (id: string) => {
    const allCategories = [...CATEGORIES.INCOME, ...CATEGORIES.EXPENSE];
    return allCategories.find(cat => cat.id === id);
};

export const groupExpensesByCategory = (transactions: Transaction[]) => {
  const expenses = transactions.filter(t => t.type === TransactionType.EXPENSE);
  const grouped = expenses.reduce((acc, expense) => {
    const category = getCategoryById(expense.categoryId);
    if (category) {
      if (!acc[category.name]) {
        acc[category.name] = { total: 0, color: category.color, count: 0 };
      }
      acc[category.name].total += expense.amount;
      acc[category.name].count += 1;
    }
    return acc;
  }, {} as { [key: string]: { total: number; color: string; count: number } });

  return Object.entries(grouped).map(([name, data]) => ({
    name,
    value: data.total,
    color: data.color,
  }));
};

export const groupTransactionsByMonth = (transactions: Transaction[]) => {
    const data = transactions.reduce((acc, { date, amount, type }) => {
        const month = new Date(date).toLocaleString('ar-EG', { month: 'short', year: 'numeric' });
        if (!acc[month]) {
            acc[month] = { name: month, دخل: 0, مصروف: 0 };
        }
        if (type === TransactionType.INCOME) {
            acc[month]['دخل'] += amount;
        } else {
            acc[month]['مصروف'] += amount;
        }
        return acc;
    }, {} as { [key: string]: { name: string; دخل: number; مصروف: number } });

    return Object.values(data).sort((a,b) => new Date(b.name).getTime() - new Date(a.name).getTime());
};