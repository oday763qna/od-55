
import React from 'react';
import { useAppContext } from '../App';

const DeveloperPage: React.FC = () => {
  const { developerInfo } = useAppContext();

  return (
    <div className="bg-white p-6 rounded-xl shadow-md text-center">
        <img 
            src={`https://i.pravatar.cc/150?u=${developerInfo.email}`} 
            alt="صورة المطور" 
            className="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-primary"
        />
        <h2 className="text-2xl font-bold text-neutral">{developerInfo.name}</h2>
        <p className="text-gray-600 mt-2">مهندس برمجيات ومطور واجهات أمامية</p>
        
        <div className="mt-6 border-t pt-6">
            <h3 className="text-lg font-bold text-primary mb-2">معلومات التواصل</h3>
            <p className="text-gray-700">
                <a href={`mailto:${developerInfo.email}`} className="hover:underline">
                    {developerInfo.email}
                </a>
            </p>
        </div>
        
        <div className="mt-4 text-sm text-gray-500">
            <p>تم تطوير هذا التطبيق كجزء من مشروع لإظهار مهارات تطوير الويب باستخدام React و TypeScript.</p>
        </div>
    </div>
  );
};

export default DeveloperPage;
