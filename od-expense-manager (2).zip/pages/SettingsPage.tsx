import React from 'react';
import { useAppContext } from '../App';

const SettingsPage: React.FC = () => {
    const { resetTransactions } = useAppContext();

    return (
        <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl shadow-md">
                <h2 className="text-xl font-bold text-neutral mb-4">إعدادات التطبيق</h2>
                <div className="border-t pt-4">
                    <h3 className="text-lg font-bold text-error">إعادة ضبط البيانات</h3>
                    <p className="text-gray-600 my-2">
                        سيؤدي هذا الإجراء إلى حذف جميع معاملاتك المالية والبدء من جديد. هذا الإجراء لا يمكن التراجع عنه.
                    </p>
                    <p className="text-sm text-gray-500 mb-4">
                        (ملاحظة: معلومات المطور لن يتم حذفها).
                    </p>
                    <button 
                        onClick={resetTransactions}
                        className="bg-error text-white font-bold py-2 px-4 rounded-lg w-full hover:bg-red-700 transition-colors"
                    >
                        إعادة ضبط بيانات التطبيق
                    </button>
                </div>
            </div>
        </div>
    );
};

export default SettingsPage;