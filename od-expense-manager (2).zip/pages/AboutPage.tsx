
import React from 'react';

const AboutPage: React.FC = () => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md space-y-4 text-gray-700">
      <h2 className="text-2xl font-bold text-primary mb-4">عن تطبيق مدير المصاريف الشخصية</h2>
      
      <p>
        تم تصميم هذا التطبيق لمساعدتك على تتبع وإدارة دخلك ومصاريفك اليومية بطريقة سهلة ومرئية. هدفنا هو تزويدك بأداة قوية تمنحك فهماً واضحاً لوضعك المالي، مما يمكنك من اتخاذ قرارات مالية أفضل.
      </p>

      <h3 className="text-xl font-bold text-neutral pt-4">الميزات الرئيسية:</h3>
      <ul className="list-disc list-inside space-y-2 pr-4">
        <li>تسجيل سريع للدخل والمصروفات.</li>
        <li>عرض ملخصات مرئية ورسوم بيانية تفاعلية.</li>
        <li>تصنيف المعاملات لفهم أنماط إنفاقك.</li>
        <li>واجهة بسيطة وداعمة للغة العربية بشكل كامل.</li>
        <li>حفظ البيانات محلياً على جهازك لضمان الخصوصية.</li>
      </ul>
      
      <h3 className="text-xl font-bold text-neutral pt-4">كيفية الاستخدام:</h3>
       <ol className="list-decimal list-inside space-y-2 pr-4">
        <li>ابدأ بإضافة أول عملية دخل أو مصروف من الزر الدائري في الشاشة الرئيسية.</li>
        <li>املأ تفاصيل العملية مثل المبلغ والفئة والتاريخ.</li>
        <li>تصفح لوحة التحكم لرؤية ملخصك المالي.</li>
        <li>انتقل إلى صفحة التقارير لتحليل أعمق لمصروفاتك.</li>
      </ol>
      <p className="pt-4">
        نأمل أن يكون هذا التطبيق مفيداً لك في رحلتك نحو إدارة مالية أفضل.
      </p>
    </div>
  );
};

export default AboutPage;
