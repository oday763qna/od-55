import React from 'react';
import { useAppContext } from '../App';
import { groupExpensesByCategory } from '../services/transactionService';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const ReportsPage: React.FC = () => {
  const { transactions } = useAppContext();
  const expenseData = groupExpensesByCategory(transactions);
  
  const RADIAN = Math.PI / 180;
  const renderCustomizedLabel = <T extends { cx: number; cy: number; midAngle: number; innerRadius: number; outerRadius: number; percent: number; index: number }>({ cx, cy, midAngle, innerRadius, outerRadius, percent }: T) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central" className="font-bold">
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  return (
    <div className="space-y-6">
        <div className="bg-white p-4 rounded-xl shadow-md">
            <h3 className="font-bold text-lg mb-4 text-neutral text-center">توزيع المصروفات حسب الفئة</h3>
             {expenseData.length > 0 ? (
                 <ResponsiveContainer width="100%" height={400}>
                    <PieChart>
                        <Pie
                            data={expenseData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={renderCustomizedLabel}
                            outerRadius={120}
                            fill="#8884d8"
                            dataKey="value"
                            nameKey="name"
                        >
                        {expenseData.map((entry) => (
                            <Cell key={`cell-${entry.name}`} fill={entry.color} />
                        ))}
                        </Pie>
                        <Tooltip formatter={(value) => new Intl.NumberFormat('en-US').format(value as number)}/>
                        <Legend />
                    </PieChart>
                 </ResponsiveContainer>
             ) : (
                <p className="text-center text-gray-500 py-10">لا توجد بيانات مصروفات لعرضها.</p>
             )}
        </div>

        <div className="bg-white p-4 rounded-xl shadow-md">
            <h3 className="font-bold text-lg mb-4 text-neutral">تصدير التقارير</h3>
            <p className="text-gray-600 mb-4">قريباً: ستتمكن من تصدير تقاريرك المالية إلى ملفات PDF أو Excel.</p>
            <div className="flex gap-4">
                <button className="bg-rose-500 text-white font-bold py-2 px-4 rounded-lg w-full opacity-50 cursor-not-allowed">تصدير PDF</button>
                <button className="bg-emerald-500 text-white font-bold py-2 px-4 rounded-lg w-full opacity-50 cursor-not-allowed">تصدير Excel</button>
            </div>
        </div>
    </div>
  );
};

export default ReportsPage;