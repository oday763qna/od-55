import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../App';
import { calculateTotals, groupTransactionsByMonth, getCategoryById } from '../services/transactionService';
import SummaryCard from '../components/SummaryCard';
import TransactionItem from '../components/TransactionItem';
import { PlusCircleIcon } from '../components/icons/Icons';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const DashboardPage: React.FC = () => {
  const { transactions } = useAppContext();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const totals = calculateTotals(transactions);
  const monthlyData = groupTransactionsByMonth(transactions);

  const filteredTransactions = useMemo(() => {
    const lowercasedQuery = searchQuery.toLowerCase().trim();
    if (!lowercasedQuery) {
      // If no search, return latest 5 transactions
      return transactions.slice(0, 5);
    }
    // If search is active, filter all transactions
    return transactions.filter(tx => {
      const category = getCategoryById(tx.categoryId);
      const descriptionMatch = tx.description.toLowerCase().includes(lowercasedQuery);
      const categoryMatch = category ? category.name.toLowerCase().includes(lowercasedQuery) : false;
      return descriptionMatch || categoryMatch;
    });
  }, [transactions, searchQuery]);


  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
         <SummaryCard title="إجمالي الدخل" amount={totals.income} colorClass="text-success" style={{ animationDelay: '100ms' }} />
         <SummaryCard title="إجمالي المصروفات" amount={totals.expense} colorClass="text-error" style={{ animationDelay: '200ms' }} />
         <SummaryCard title="الرصيد الحالي" amount={totals.balance} colorClass="text-secondary" style={{ animationDelay: '300ms' }} />
      </div>

      <div className="bg-white p-4 rounded-xl shadow-md animate-slideInUp" style={{ animationDelay: '400ms' }}>
        <h3 className="font-bold text-lg mb-4 text-neutral">نظرة عامة شهرية</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={monthlyData} margin={{ top: 5, right: 2, left: 2, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" angle={-45} textAnchor="end" height={60} interval={0} fontSize={12} />
            <YAxis tickFormatter={(value) => new Intl.NumberFormat('en-US').format(value as number)} fontSize={12} />
            <Tooltip formatter={(value, name) => [new Intl.NumberFormat('en-US').format(value as number), name === 'دخل' ? 'الدخل' : 'المصروف']}/>
            <Legend />
            <Bar dataKey="دخل" fill="#10b981" name="الدخل" />
            <Bar dataKey="مصروف" fill="#f43f5e" name="المصروف" />
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="animate-slideInUp" style={{ animationDelay: '500ms' }}>
        <h3 className="font-bold text-lg mb-4 text-neutral">
            {searchQuery ? 'نتائج البحث' : 'أحدث العمليات'}
        </h3>
        
        <div className="mb-4">
            <input
                type="text"
                placeholder="ابحث في العمليات (حسب الوصف أو الفئة)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent bg-white"
            />
        </div>

        <div className="space-y-3">
            {transactions.length === 0 ? (
                 <p className="text-center text-gray-500 p-4 bg-white rounded-lg">لا توجد عمليات بعد. ابدأ بإضافة واحدة!</p>
            ) : filteredTransactions.length > 0 ? (
                filteredTransactions.map((tx, index) => (
                    <TransactionItem key={tx.id} transaction={tx} style={{ animationDelay: `${index * 50}ms` }} />
                ))
            ) : (
                <p className="text-center text-gray-500 p-4 bg-white rounded-lg">لا توجد نتائج مطابقة لبحثك.</p>
            )}
        </div>
      </div>
      
      <button 
        onClick={() => navigate('/add')}
        className="fixed bottom-20 right-4 md:right-1/2 md:translate-x-[240px] bg-primary text-white p-4 rounded-full shadow-lg hover:bg-primary-focus transition-transform transform hover:scale-105"
        aria-label="إضافة عملية جديدة"
       >
        <PlusCircleIcon className="w-8 h-8"/>
       </button>
    </div>
  );
};

export default DashboardPage;