import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../App';
import { TransactionType, CATEGORIES } from '../types';

const AddTransactionPage: React.FC = () => {
  const { addTransaction } = useAppContext();
  const navigate = useNavigate();
  
  const [type, setType] = useState<TransactionType>(TransactionType.EXPENSE);
  const [categoryId, setCategoryId] = useState<string>(CATEGORIES.EXPENSE[0].id);
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [description, setDescription] = useState('');

  const handleTypeChange = (newType: TransactionType) => {
    setType(newType);
    setCategoryId(newType === TransactionType.INCOME ? CATEGORIES.INCOME[0].id : CATEGORIES.EXPENSE[0].id);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !categoryId || !date) {
        alert('يرجى ملء جميع الحقول المطلوبة.');
        return;
    }
    addTransaction({
        type,
        categoryId,
        amount: parseFloat(amount),
        date,
        description,
    });
    navigate('/');
  };
  
  const categories = type === TransactionType.INCOME ? CATEGORIES.INCOME : CATEGORIES.EXPENSE;

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
        <div className="grid grid-cols-2 gap-4 mb-6">
            <button 
                onClick={() => handleTypeChange(TransactionType.EXPENSE)}
                className={`p-3 rounded-lg font-bold text-lg transition-colors ${type === TransactionType.EXPENSE ? 'bg-error text-white shadow-md' : 'bg-base-200 text-gray-700'}`}>
                مصروف
            </button>
            <button 
                onClick={() => handleTypeChange(TransactionType.INCOME)}
                className={`p-3 rounded-lg font-bold text-lg transition-colors ${type === TransactionType.INCOME ? 'bg-success text-white shadow-md' : 'bg-base-200 text-gray-700'}`}>
                دخل
            </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-1">المبلغ</label>
                <input
                    type="number"
                    id="amount"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    placeholder="0.00"
                    required
                />
            </div>
             <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">الفئة</label>
                <select
                    id="category"
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent bg-white"
                    required
                >
                    {categories.map(cat => (
                        <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                </select>
            </div>
             <div>
                <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-1">التاريخ</label>
                <input
                    type="date"
                    id="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    required
                />
            </div>
             <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">الوصف (اختياري)</label>
                <textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary focus:border-transparent"
                    rows={3}
                    placeholder="أضف ملاحظات..."
                />
            </div>
            <button type="submit" className="w-full bg-primary text-white font-bold py-3 px-4 rounded-lg hover:bg-primary-focus transition-colors shadow-md hover:shadow-lg">
                حفظ العملية
            </button>
        </form>
    </div>
  );
};

export default AddTransactionPage;