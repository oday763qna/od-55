import React from 'react';
import { Transaction, TransactionType } from '../types';
import { getCategoryById } from '../services/transactionService';

interface TransactionItemProps {
  transaction: Transaction;
  style?: React.CSSProperties;
}

const TransactionItem: React.FC<TransactionItemProps> = ({ transaction, style }) => {
  const category = getCategoryById(transaction.categoryId);
  const isIncome = transaction.type === TransactionType.INCOME;

  const formattedAmount = new Intl.NumberFormat('en-US').format(transaction.amount);

  const formattedDate = new Date(transaction.date).toLocaleDateString('ar-EG', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    numberingSystem: 'latn'
  });

  return (
    <div className="flex items-center justify-between bg-white p-3 rounded-lg mb-3 shadow-sm hover:shadow-md transition-shadow animate-slideInUp" style={style}>
      <div className="flex items-center">
        <div className="w-10 h-10 rounded-full flex items-center justify-center me-4" style={{ backgroundColor: category?.color || '#ccc' }}>
            <span className="text-white font-bold text-lg">{category?.name.charAt(0)}</span>
        </div>
        <div>
          <p className="font-bold text-gray-800">{category?.name}</p>
          <p className="text-sm text-gray-500">{transaction.description}</p>
        </div>
      </div>
      <div className="text-left">
        <p className={`font-bold text-lg ${isIncome ? 'text-success' : 'text-error'}`}>
          {isIncome ? `+${formattedAmount}` : `-${formattedAmount}`}
        </p>
        <p className="text-xs text-gray-400">{formattedDate}</p>
      </div>
    </div>
  );
};

export default TransactionItem;