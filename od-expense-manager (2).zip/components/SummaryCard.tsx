import React from 'react';

interface SummaryCardProps {
  title: string;
  amount: number;
  colorClass: string;
  style?: React.CSSProperties;
}

const SummaryCard: React.FC<SummaryCardProps> = ({ title, amount, colorClass, style }) => {
  const formattedAmount = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);

  return (
    <div className="bg-white p-4 rounded-xl shadow-md flex-1 text-center animate-slideInUp" style={style}>
      <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
      <p className={`text-2xl font-bold ${colorClass}`}>{formattedAmount}</p>
    </div>
  );
};

export default SummaryCard;