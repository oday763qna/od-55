import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { HomeIcon, ChartBarIcon, DocumentTextIcon, CogIcon, UserIcon } from './icons/Icons';

interface LayoutProps {
  children: React.ReactNode;
}

const navItems = [
    { path: '/', label: 'الرئيسية', icon: HomeIcon },
    { path: '/reports', label: 'تقارير', icon: ChartBarIcon },
    { path: '/about', label: 'عن التطبيق', icon: DocumentTextIcon },
    { path: '/developer', label: 'المطور', icon: UserIcon },
    { path: '/settings', label: 'الإعدادات', icon: CogIcon }
];

const pageTitles: { [key: string]: string } = {
    '/': 'لوحة التحكم',
    '/add': 'إضافة عملية جديدة',
    '/edit': 'تعديل العملية',
    '/reports': 'التقارير والتحليلات',
    '/about': 'عن التطبيق',
    '/developer': 'معلومات المطور',
    '/settings': 'الإعدادات'
};

const Layout: React.FC<LayoutProps> = ({ children }) => {
    const location = useLocation();
    const currentTitle = pageTitles[location.pathname] || 'مدير المصاريف الشخصية';

  return (
    <div className="flex flex-col h-screen max-w-lg mx-auto bg-base-200">
      <header className="bg-primary text-white p-4 text-center shadow-md z-10 sticky top-0">
        <h1 className="text-xl font-bold">{currentTitle}</h1>
      </header>
      
      <main className="flex-grow p-4 overflow-y-auto pb-24 animate-fadeIn">
        {children}
      </main>

      <nav className="fixed bottom-0 right-0 left-0 max-w-lg mx-auto bg-white border-t border-base-300 shadow-[0_-1px_10px_rgba(0,0,0,0.05)] z-10">
        <div className="flex justify-around items-center h-16">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => 
                `flex flex-col items-center justify-center w-full text-sm font-medium transition-colors duration-200 ${isActive ? 'text-primary' : 'text-gray-500 hover:text-primary'}`
              }
            >
              <item.icon className="w-6 h-6 mb-1" />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
};

export default Layout;