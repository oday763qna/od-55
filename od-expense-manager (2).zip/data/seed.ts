
import { Transaction } from '../types';

export const getSeedData = (): Transaction[] => {
  return [];
};
